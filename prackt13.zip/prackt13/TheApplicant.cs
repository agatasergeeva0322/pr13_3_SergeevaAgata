﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prackt13
{
    class TheApplicant
    {
        private string name;
        private string lastname;
        private string otfather;
        private double medium;

        public TheApplicant(string name, string lastname, string otfather, double medium)
        {
            this.name = name;
            this.lastname = lastname;
            this.otfather = otfather;
            this.medium = medium;
        }
        public string get_name()
        {
            return this.name;
        }
        public void set_name(string n)
        {
            this.name = n;
        }
        public string get_lastname()
        {
            return this.lastname;
        }
        public void set_lastname(string n)
        {
            this.lastname = n;
        }
        public string get_otfather()
        {
            return this.otfather;
        }
        public void set_otfather(string n)
        {
            this.otfather = n;
        }
        public double get_medium()
        {
            return this.medium;
        }
        public void set_medium(double n)
        {
            this.medium = n;
        }

    }
}
